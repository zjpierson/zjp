  (c) SYSTEC electronic GmbH, D-07973 Greiz, August-Bebel-Str. 29
        www.systec-electronic.com

                                                       2012-03-08

        SocketCAN Driver for USB-CANmodul series
        =========================================

Requirements
-------------

* Linux Kernel version >= 2.6.32

* Following kernel options have to be set:

CONFIG_CAN=m
CONFIG_CAN_RAW=m
CONFIG_CAN_BCM=m
CONFIG_CAN_DEV=m
CONFIG_CAN_CALC_BITTIMING=y

* CAN utilities from the SocketCAN repository for first tests

$ git clone git://gitorious.org/linux-can/can-utils.git
$ cd can-utils
$ make

  Old repository on berlios:
	$ svn checkout svn://svn.berlios.de/socketcan/trunk socketcan
	$ cd socketcan/can-utils
	$ make


Limitations
------------

* Firmware version >=4.06 must be installed on USB-CANmodul.
  In case of an older firmware version, please connect the USB-CANmodul to a
  Windows PC with a recent driver version.
* There is currently no way to read out or set the digital I/Os of the
  user port or the CAN port (signals EN, /STB, /ERR, /TRM).
* No support for the obsolete modules GW-002 and GW-001.
  This is not planned at all.


Build the driver
-----------------

Run make within the source directory

$ cd systec_can
$ make


Load the driver from the local source directory
------------------------------------------------

1. Load basic CAN drivers

$ sudo modprobe can_raw
$ sudo modprobe can_dev

2. Install firmware

$ sudo make firmware_install

3. Load USB-CANmodul driver

$ sudo insmod systec_can.ko

- OR -

Install the driver and firmware system-wide
--------------------------------------------

$ sudo make modules_install
$ sudo make firmware_install

The kernel module should now be loaded automatically by udev
when the device is connected.


Run basic tests
----------------

1. Connect the USB-CANmodul to the PC

2. Set up bitrate and start up the CAN interface

$ ip link set can0 type can bitrate 125000
- OR if CONFIG_CAN_CALC_BITTIMING is undefined -
$ ip link set can0 type can tq 500 prop-seg 6 phase-seg1 7 phase-seg2 2

$ ifconfig can0 up

3. Dump the traffic on the CAN bus

$ cd can-utils
$ ./candump can0

to display error frames (option -e is supported in newer candump versions only):

$ ./candump -e can0,0:0,#FFFFFFFF

4. Transmit one CAN frame

$ cd can-utils
$ ./cangen -n 1 -I 640 -L 8 -D 4000100000000000 can0

5. Print out some statistics

$ ip -details -statistics link show can0

6. Restart CAN channel in case of bus-off (i.e. short circuit)

$ ip link set can0 type can restart


Hardware address
-----------------

The hardware address (like the MAC address of Ethernet controllers)
of each CAN channel as shown with
`ip link show can0` or `ifconfig can0` is formed the following way:

S0:S1:S2:S3:DN:CN

Sx - Serial Number in Hex with S0 contains the most significant byte
DN - Device Number
CN - Channel Number (00 - CAN1, 01 - CAN2)

The unique hardware address can be used by a special udev rule to
assign stable interface names and numbers.


