#!/bin/bash

sudo modprobe can_raw
sudo modprobe can_dev
sudo make firmware_install
sudo insmod systec_can.ko

if [ "$1" == "" ]
then
  DEV="can0"
else
  DEV="$1"
fi

sudo ip link set $DEV type can bitrate 250000
sudo ifconfig $DEV up

