#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0xc4e4328b, "module_layout" },
	{ 0xe4afc202, "usb_deregister" },
	{ 0x8c03d20c, "destroy_workqueue" },
	{ 0x6cc65608, "usb_register_driver" },
	{ 0x43a53735, "__alloc_workqueue_key" },
	{ 0x77cc9591, "release_firmware" },
	{ 0x951a9706, "request_firmware" },
	{ 0x91715312, "sprintf" },
	{ 0x12da5bb2, "__kmalloc" },
	{ 0xd0d8621b, "strlen" },
	{ 0x3a1179e6, "usb_control_msg" },
	{ 0xa6332cd0, "__mutex_init" },
	{ 0x834c1d11, "kmem_cache_alloc_trace" },
	{ 0xb84acc53, "kmalloc_caches" },
	{ 0x14aada7a, "close_candev" },
	{ 0x6e5c5e19, "can_get_echo_skb" },
	{ 0xdd47315e, "alloc_can_skb" },
	{ 0x76b9be17, "can_free_echo_skb" },
	{ 0x50eedeb8, "printk" },
	{ 0x16305289, "warn_slowpath_null" },
	{ 0x4abcc945, "consume_skb" },
	{ 0xc4756df2, "can_put_echo_skb" },
	{ 0xc61f47e5, "kfree_skb" },
	{ 0x92c90e22, "queue_work" },
	{ 0x17915f64, "netdev_warn" },
	{ 0x8142879a, "__netif_schedule" },
	{ 0x6f87a20f, "netif_carrier_on" },
	{ 0x8834396c, "mod_timer" },
	{ 0x2d8c4784, "netif_carrier_off" },
	{ 0x4cfbb58f, "netif_rx" },
	{ 0x2555cd50, "alloc_can_err_skb" },
	{ 0x44b473ae, "netdev_err" },
	{ 0xff4ef4d1, "netif_device_detach" },
	{ 0x7d11c268, "jiffies" },
	{ 0x8ebd9f47, "usb_free_coherent" },
	{ 0xd5b13ce2, "usb_unanchor_urb" },
	{ 0x33ed47ea, "usb_submit_urb" },
	{ 0x80a7b8ee, "usb_anchor_urb" },
	{ 0x8471f3ff, "usb_alloc_coherent" },
	{ 0x978323aa, "usb_alloc_urb" },
	{ 0x2efd34d9, "open_candev" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0xc4c0643a, "mutex_unlock" },
	{ 0x7929068b, "mutex_lock" },
	{ 0x277c54fa, "dev_err" },
	{ 0x3fe26c72, "register_candev" },
	{ 0x68dfc59f, "__init_waitqueue_head" },
	{ 0xf7ba7b37, "alloc_candev" },
	{ 0xdb3ec719, "usb_bulk_msg" },
	{ 0x2e60bace, "memcpy" },
	{ 0x4f111cc1, "dev_warn" },
	{ 0xd344a61d, "usb_unlink_urb" },
	{ 0x37a0cba, "kfree" },
	{ 0x33ff84a3, "usb_free_urb" },
	{ 0xac8996a8, "dev_set_drvdata" },
	{ 0x944278fa, "dev_get_drvdata" },
	{ 0xd5e04cc4, "free_candev" },
	{ 0xc80013cc, "unregister_netdev" },
	{ 0xdf4a2c6e, "_dev_info" },
	{ 0x8c4db1b5, "usb_kill_anchored_urbs" },
	{ 0xb4390f9a, "mcount" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=can-dev";

MODULE_ALIAS("usb:v0878p1103d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0878p1104d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0878p1105d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0878p1144d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0878p1145d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0878p1101d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0878p1181d*dc*dsc*dp*ic*isc*ip*in*");

MODULE_INFO(srcversion, "802F5D81A54FCB4A287DF5A");
