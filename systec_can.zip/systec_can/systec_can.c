/*
 *
 * (C) Copyright 2011 Heino Gutschmidt
 * (C) 2011 SYS TEC electronic GmbH, Daniel Krueger
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 * MA 02111-1307 USA
 */

#include <linux/init.h>
#include <linux/signal.h>
#include <linux/slab.h>
#include <linux/module.h>
#include <linux/netdevice.h>
#include <linux/usb.h>
#include <linux/version.h>
#include <linux/mutex.h>
#include <linux/if_arp.h>
#include <linux/workqueue.h>
#include <linux/firmware.h>


#include <linux/can.h>
#include <linux/can/dev.h>
#include <linux/can/error.h>

#define SYSTEC_MODULE_VERSION   "0.4"
#define SYSTEC_MODULE_DESC      "SYS TEC electronic USB-CANmodul Series Driver " \
                                SYSTEC_MODULE_VERSION

#define SYSTEC_DEBUG_BUFFER 0
#define SYSTEC_DEBUG_STAT_CB 0
#define SYSTEC_DEBUG_DATA_CB 0
#define SYSTEC_DEBUG_TX 0
#define SYSTEC_DEBUG_BITTIMING 0
#define SYSTEC_DEBUG_CMD 0
#define SYSTEC_DEBUG_STATUS_CMD 0
#define SYSTEC_DEBUG_ERR_HANDLING 1
#define SYSTEC_DEBUG_USB_DISCONNECT 1

#define MAX_TX_URBS 10
#define MAX_RX_URBS 10
#define RX_BUFFER_SIZE      64
#define INTR_IN_BUFFER_SIZE 4

/* size of command */
#define SYSTEC_CMD_SIZE     8

/* number of endpoints */
#define SYSTEC_NUM_ENDPOINTS 5

#define SYSTEC_EP_DATA_OUT 0
#define SYSTEC_EP_MSG_OUT  1
#define SYSTEC_EP_DATA_IN  2
#define SYSTEC_EP_MSG_IN   3
#define SYSTEC_EP_STAT_IN  4

/* for can socket internal calculation, 48MHz clock */
#define SYSTEC_DEVICE_CLOCK 48000000

/* timeout for bulk transfers - 1000ms */
#define SYSTEC_BULK_TIMEOUT     1000

/* polling time of int (status) urbs - 1ms */
#define SYSTEC_INT_URB_POLL_TIME        1

#define SYSTEC_CAN_STATE_ERR_WARN       0x00040000
#define SYSTEC_CAN_STATE_ERR_PASS       0x00080000
#define SYSTEC_CAN_STATE_ERR_BOFF       0x00100000


#define USBCAN_VRREQ_START_UPDATE       0xB1    // OUT: void
#define USBCAN_VRREQ_WRITE_UPDATE       0xB2    // OUT: INTEL-HEX-RECORD
#define USBCAN_VRREQ_STOPP_UPDATE       0xB3    // OUT: void
#define USBCAN_VRREQ_CHECK_UPDATE       0xB4    // IN:  dwErrorCode, dwCryptCrc32, dwReserve
#define USBCAN_VRREQ_WRITE_FLASH        0xB5    // OUT: dwBase, dwSize, fReset
#define USBCAN_VRREQ_RECONNECT          0xB6    // OUT: void
#define USBCAN_VRREQ_READ_FW_VERSION    0xB9    // IN:  dwVersion   // always means FwVersion of Firmware (not supported in Firmware < V4.06)
#define USBCAN_VRREQ_CHECK_CRC          0xBA    // OUT: dwBase, dwSize
#define USBCAN_VRREQ_GET_CRC_RESULT     0xBB    // IN:  dwErrorCode, dwCryptCrc32, dwReserve

/* from Include/Ucanmcpc.h */
#define USBCAN_CMD_SHUTDOWN             4
#define USBCAN_CMD_RESET                5
#define USBCAN_CMD_READEEPROM           6
#define USBCAN_CMD_SETAMR               11      // -> dwAMR
#define USBCAN_CMD_SETACR               12      // -> dwACR
#define USBCAN_CMD_SETCANMODE           13      // -> bMode
#define USBCAN_CMD_SETBAUDRATE_EX       25

#define USBCAN_DATAFF_DLC               0x0F

#define USBCAN_DATAFF_POS_CHANNEL       4
#define USBCAN_DATAFF_CHANNEL1          (1 << USBCAN_DATAFF_POS_CHANNEL)

#define USBCAN_ADDRESS_FIRMWARE         0x00006000
#define USBCAN_UPDATE_BUFFER_SIZE       0x00006000

/* from Host_GENERIC/Include/Usbcan32.h */
#define USBCAN_MSG_FF_EXT       0x80
#define USBCAN_MSG_FF_RTR       0x40

/* from Host_GENERIC/Library/Ucancmd.c */
#define USBCAN_EEPROM_PID                   0x03
#define USBCAN_EEPROM_SERIALNR              0x08
#define USBCAN_EEPROM_DEVICENR              0x0c

/* from Include/Vermco.h */
#define GETPC_MAJOR_VER(ver)            ((ver) & 0x000000FF)
#define GETPC_MINOR_VER(ver)            (((ver) & 0x0000FF00) >> 8)
#define GETPC_RELEASE_VER(ver)          (((ver) & 0xFFFF0000) >> 16)

#define REQ_FW_MAJOR                        4
#define REQ_FW_MINOR                       15
#define REQ_FW_RELEASE_1103                55
#define REQ_FW_RELEASE_1104                44
#define REQ_FW_RELEASE_1105                28
#define REQ_FW_RELEASE_1144                44
#define REQ_FW_RELEASE_1145                28

#define FIRMWARE_FILE(major, minor, release, type) \
	"systec_can-" __stringify(type) "-" __stringify(major) "." __stringify(minor) ".r" __stringify(release) ".fw"

#define FW_VERSION(major, minor, release)   (major | (minor << 8) | (release << 16))

/* name of firmware image */
#define FIRMWARE_NAME "systec_can-%.4x-%d.%d.r%d.fw"

static struct can_bittiming_const systec_can_bittiming_const = {
        .name = KBUILD_MODNAME,
        .tseg1_min = 1,
        .tseg1_max = 16,
        .tseg2_min = 1,
        .tseg2_max = 8,
        .sjw_max = 4,
        .brp_min = 1,
        .brp_max = 255, /* if > 127 the CLK flag is used */
        .brp_inc = 1,
};

struct systec_pid_chan {
        u16 pid;                 /* product id                        */
        u32 required_fw_version; /* required firmware version         */
};

/* define product id and required firmware version */
static struct systec_pid_chan systec_pid_chan_table[] = {
        {0x1103, FW_VERSION(REQ_FW_MAJOR, REQ_FW_MINOR, REQ_FW_RELEASE_1103)}, /* 8 or 16 channel device */
        {0x1104, FW_VERSION(REQ_FW_MAJOR, REQ_FW_MINOR, REQ_FW_RELEASE_1104)}, /* single channel device */
        {0x1105, FW_VERSION(REQ_FW_MAJOR, REQ_FW_MINOR, REQ_FW_RELEASE_1105)}, /* dual channel device */
        {0x1144, FW_VERSION(REQ_FW_MAJOR, REQ_FW_MINOR, REQ_FW_RELEASE_1144)}, /* CANUSB4 KSPS-0809 */
        {0x1145, FW_VERSION(REQ_FW_MAJOR, REQ_FW_MINOR, REQ_FW_RELEASE_1145)},/* 3204013 */
        {0, 0}
};

static struct usb_device_id systec_can_main_table[] = {
        {USB_DEVICE(0x0878, 0x1103)},   /* sysWORXX USB-CANmodul8 or 16 */
        {USB_DEVICE(0x0878, 0x1104)},   /* sysWORXX USB-CANmodul1 */
        {USB_DEVICE(0x0878, 0x1105)},   /* sysWORXX USB-CANmodul2 */
        {USB_DEVICE(0x0878, 0x1144)},   /* CANUSB4 KSPS-0809 */
        {USB_DEVICE(0x0878, 0x1145)},   /* order no. 3204013 */
        {USB_DEVICE(0x0878, 0x1101)},   /* running device (normal Windows driver) */
        {USB_DEVICE(0x0878, 0x1181)},   /* running device (Windows network driver) */
        {} /* Terminating entry */
};

MODULE_DEVICE_TABLE(usb, systec_can_main_table);

struct systec_tx_urb_context {
        struct systec_can_chan *chan;

        u32 echo_index;
        u8 dlc;
};

/* work structure to schedule commands */
struct systec_work {
        struct work_struct work;
        struct systec_can_chan *chan;
        enum can_state chan_state;
};

struct systec_can_shared;

/* ressources per channel */
struct systec_can_chan {
        struct can_priv can; /* must be the first member */

        /* points to shared ressources between both channels */
        struct systec_can_shared *shared_res;

        /* ressources per channel */
        u8 chan_no;     /* channel number */

        /* internal device status delivered by status endpoint */
        u32 mod_status_int;

        /* current bittiming (extended baudrate register) */
        u32 baud_ex_reg;

        int open_time;

        atomic_t active_tx_urbs;
        struct usb_anchor tx_submitted;
        struct systec_tx_urb_context tx_contexts[MAX_TX_URBS];

        /* corresponding net device */
        struct net_device *netdev;

        /* prepared work to restart channel (bus-off) within timer function */
        struct systec_work restart_work;
};

/* shared ressources between both channels */
struct systec_can_shared {
        /* serial number (device eeprom) */
        u8 serial_no[4];

        /* device number (device eeprom) */
        u8 device_no;

        /* usb device */
        struct usb_device *udev;

        /* reference to private data of each channel */
        struct systec_can_chan *channels[2];

        struct usb_anchor rx_submitted;
        u8 rx_urb_running;

        struct urb *intr_urb;
        u8 *intr_in_buffer;
        u8 intr_urb_running;

        u8 *tx_cmd_buffer;
        u8 *rx_cmd_buffer;
        struct mutex cmd_pending;

        u8 endpoint_addresses[SYSTEC_NUM_ENDPOINTS];

        struct mutex lock_shared;
};

/* command message: driver -> CAN-Modul */
struct __attribute__ ((packed)) systec_cmd_msg {
        u32 size;
        u8  cmd_data[SYSTEC_CMD_SIZE];
};

/* CAN message with standard ID */
struct __attribute__ ((packed)) systec_can_std_msg {
    u16  can_id;
    u8   data[8];
    u8   reserved[2];
};

/* CAN message with extended ID */
struct __attribute__ ((packed)) systec_can_ext_msg {
    u32  can_id;
    u8   data[8];
};

/* the internal CAN message */
struct __attribute__ ((packed)) systec_can_msg {
        u8   format;    /* first byte is always the format byte */
        union {         /* handle both types of ID              */
                struct  systec_can_std_msg can_std_msg;
                struct  systec_can_ext_msg can_ext_msg;
        } msg;
        u8   timestamp[3]; /* last 3 bytes are the timestamp */
};

/* binary Intel hex record from usbcan_loader.h */
#define MAX_INTEL_HEX_RECORD_LENGTH 16
struct __attribute__ ((packed)) intel_hex_record
{
    u8 length;
    u16 address;
    u8 type;
    u8  data[MAX_INTEL_HEX_RECORD_LENGTH];

};

/* this hex record type indicates a header record */
#define HEX_RECORD_TYPE_HEADER 0xff


/* prototypes */
static void systec_can_main_disconnect(struct usb_interface *intf);
static int systec_can_main_probe(struct usb_interface *intf,
                         const struct usb_device_id *id);
static int systec_can_main_probe_boot(struct usb_interface *intf,
                         const struct usb_device_id *id);
static int systec_can_open(struct net_device *netdev);
static int systec_can_close(struct net_device *netdev);
static netdev_tx_t systec_can_start_xmit(struct sk_buff *skb, struct net_device *netdev);
static int systec_can_set_bittiming(struct net_device *netdev);
static int systec_can_set_mode(struct net_device *netdev, enum can_mode mode);
static void systec_unlink_urbs(struct systec_can_chan *chan);
static int systec_can_send_cmd(struct systec_can_shared *shared_res, struct systec_cmd_msg *msg);
static int systec_can_rcv_cmd_stat(struct systec_can_shared *shared_res, struct systec_cmd_msg *msg);

#if SYSTEC_DEBUG_BUFFER
static void systec_dump_cmd_buf(u8 *buffer);
static void systec_dump_msg_buf(u8 *buffer);
#endif
#if SYSTEC_DEBUG_STAT_CB
static void systec_dump_buf(u8 *buffer, int size);
#endif

static void systec_can_read_stat_callback(struct urb *urb);
static void systec_can_read_data_callback(struct urb *urb);
static void systec_can_write_data_callback(struct urb *urb);
static void systec_can_rx_can_msg(struct systec_can_chan *chan, u8 *msg_buf);
static int systec_dual_chan_device(struct systec_can_shared *shared_res);
static void systec_handle_status_change(struct systec_can_chan *chan, u32 mod_status_int_new);
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 33)
#define get_can_dlc(i)  (min_t(__u8, (i), 8))
static struct sk_buff *alloc_can_skb(struct net_device *dev, struct can_frame **cf);
static struct sk_buff *alloc_can_err_skb(struct net_device *dev, struct can_frame **cf);
#endif
static void systec_work_chan_restart(struct work_struct *work);
static int systec_get_serial_no(struct systec_can_shared *shared_res);


/* the usb handles to operate the CAN device */
static struct usb_driver systec_can_driver = {
        .name = KBUILD_MODNAME,
        .probe = systec_can_main_probe,
        .disconnect = systec_can_main_disconnect,
        .id_table = systec_can_main_table,
};

/* the network handles to operate the CAN device */
static const struct net_device_ops systec_can_netdev_ops = {
        .ndo_open = systec_can_open,
        .ndo_stop = systec_can_close,
        .ndo_start_xmit = systec_can_start_xmit,
};

/* command work queue */
static struct workqueue_struct *cmd_wq;

static int systec_can_open(struct net_device *netdev)
{
        struct systec_can_chan *chan = netdev_priv(netdev);
        int err;
        int i;
        struct urb *new_urb;
        u8 *new_buf;
        struct systec_cmd_msg cmd;
        int ret_val;

        netdev_dbg(netdev, "systec_can_open\n");

        /* open CAN device */
        err = open_candev(netdev);
        if (err) {
                return err;
        }

        mutex_lock(&chan->shared_res->lock_shared);

        if (!chan->shared_res->rx_urb_running) {
                /* create the rx URBs since there is not any URB running */
                for (i = 0; i < MAX_RX_URBS; i++) {
                        new_urb = NULL;
                        new_buf = NULL;

                        /* alloc the URB */
                        new_urb = usb_alloc_urb(0, GFP_KERNEL);
                        if (!new_urb) {
                                netdev_err(netdev,
                                        "not enough memory for URB\n");

                                mutex_unlock(&chan->shared_res->lock_shared);
                                return(-ENOMEM);
                        }

                        /* create the buffer for the URB */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 34)
                        new_buf = usb_alloc_coherent(chan->shared_res->udev, RX_BUFFER_SIZE, GFP_KERNEL,
                                                   &new_urb->transfer_dma);
#else
                        new_buf = usb_buffer_alloc(chan->shared_res->udev, RX_BUFFER_SIZE, GFP_KERNEL,
                                                   &new_urb->transfer_dma);
#endif

                        if (!new_buf) {
                                netdev_err(netdev,
                                        "not enough memory for URB buffer\n");

                                usb_free_urb(new_urb);
                                mutex_unlock(&chan->shared_res->lock_shared);
                                return(-ENOMEM);
                        }

                        usb_fill_bulk_urb(new_urb, chan->shared_res->udev,
                                         usb_rcvbulkpipe(chan->shared_res->udev,
                                            chan->shared_res->endpoint_addresses[SYSTEC_EP_DATA_IN]),
                                         new_buf, RX_BUFFER_SIZE,
                                         systec_can_read_data_callback, chan->shared_res);
                        new_urb->transfer_flags |= URB_NO_TRANSFER_DMA_MAP;
                        usb_anchor_urb(new_urb, &chan->shared_res->rx_submitted);

                        err = usb_submit_urb(new_urb, GFP_KERNEL);
                        if (err) {
                                if (err == -ENODEV) {
                                        netif_device_detach(chan->netdev);
                                }

                                usb_unanchor_urb(new_urb);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 34)
                                usb_free_coherent(chan->shared_res->udev, RX_BUFFER_SIZE, new_buf,
                                                new_urb->transfer_dma);
#else
                                usb_buffer_free(chan->shared_res->udev, RX_BUFFER_SIZE, new_buf,
                                                new_urb->transfer_dma);
#endif
                        }

                        /* the driver is finished with the URB */
                        usb_free_urb(new_urb);
                }


                /* check if one urb could be submited at least */
                if (i == 0) {
                        dev_err(netdev->dev.parent, "could not submit any read data urb\n");

                        mutex_unlock(&chan->shared_res->lock_shared);
                        return (err);
                }

                if (i < MAX_RX_URBS) {
                        dev_warn(netdev->dev.parent, "only %d of %d urbs could be submited\n", i, MAX_RX_URBS);
                }

                chan->shared_res->rx_urb_running = 1;
        }
        else {
                /* both channels are open now */
                chan->shared_res->rx_urb_running = 2;
        }

        if (!chan->shared_res->intr_urb_running)
        {
                /* setup status urb */
                new_urb = usb_alloc_urb(0, GFP_KERNEL);
                if (new_urb) {
                        chan->shared_res->intr_urb = new_urb;

                        usb_fill_int_urb(new_urb, chan->shared_res->udev,
                                         usb_rcvintpipe(chan->shared_res->udev,
                                        chan->shared_res->endpoint_addresses[SYSTEC_EP_STAT_IN]),
                                        chan->shared_res->intr_in_buffer,
                                        INTR_IN_BUFFER_SIZE,
                                        systec_can_read_stat_callback, chan->shared_res,
                                        SYSTEC_INT_URB_POLL_TIME);

                        err = usb_submit_urb(chan->shared_res->intr_urb, GFP_KERNEL);
                        if (err) {
                                usb_free_urb(new_urb);
                                chan->shared_res->intr_urb = NULL;


                                if (err == -ENODEV) {
                                        netif_device_detach(chan->netdev);
                                }

                                dev_warn(netdev->dev.parent, "intr URB submit failed: %d\n",
                                        err);

                                mutex_unlock(&chan->shared_res->lock_shared);
                                return(err);
                        }
                        else {
                                chan->shared_res->intr_urb_running = 1;
                        }
                }
                else {
                        netdev_err(netdev, "Couldn't alloc intr URB\n");

                        mutex_unlock(&chan->shared_res->lock_shared);
                        return(-ENOMEM);
                }
        }
        else {
                /* both channels are open now */
                chan->shared_res->intr_urb_running = 2;
        }


        mutex_unlock(&chan->shared_res->lock_shared);


        /* clear can status */
        memset(&cmd, 0, sizeof(struct systec_cmd_msg));
        cmd.size = 8;
        cmd.cmd_data[0] = USBCAN_CMD_RESET;
        cmd.cmd_data[4] = 0xff;
        cmd.cmd_data[5] = 0xfe;
        cmd.cmd_data[6] = chan->chan_no;
        mutex_lock(&chan->shared_res->cmd_pending);
        ret_val = systec_can_send_cmd(chan->shared_res, &cmd);
        ret_val = systec_can_rcv_cmd_stat(chan->shared_res, &cmd);
        mutex_unlock(&chan->shared_res->cmd_pending);

        /* set AMR */
        memset(&cmd, 0, sizeof(struct systec_cmd_msg));
        cmd.size = 8;
        cmd.cmd_data[0] = USBCAN_CMD_SETAMR;
        cmd.cmd_data[6] = chan->chan_no;
        *((u32 *) &cmd.cmd_data[1]) = 0xffffffff;
        mutex_lock(&chan->shared_res->cmd_pending);
        ret_val = systec_can_send_cmd(chan->shared_res, &cmd);
        ret_val = systec_can_rcv_cmd_stat(chan->shared_res, &cmd);
        mutex_unlock(&chan->shared_res->cmd_pending);

        /* set ACR */
        memset(&cmd, 0, sizeof(struct systec_cmd_msg));
        cmd.size = 8;
        cmd.cmd_data[0] = USBCAN_CMD_SETACR;
        cmd.cmd_data[6] = chan->chan_no;
        *((u32 *) &cmd.cmd_data[1]) = 0x0;
        mutex_lock(&chan->shared_res->cmd_pending);
        ret_val = systec_can_send_cmd(chan->shared_res, &cmd);
        ret_val = systec_can_rcv_cmd_stat(chan->shared_res, &cmd);
        mutex_unlock(&chan->shared_res->cmd_pending);

        /* set CAN mode */
        memset(&cmd, 0, sizeof(struct systec_cmd_msg));
        cmd.size = 8;
        cmd.cmd_data[0] = USBCAN_CMD_SETCANMODE;
        cmd.cmd_data[1] = 0; /* standard r/w mode */
        cmd.cmd_data[6] = chan->chan_no;
        mutex_lock(&chan->shared_res->cmd_pending);
        ret_val = systec_can_send_cmd(chan->shared_res, &cmd);
        ret_val = systec_can_rcv_cmd_stat(chan->shared_res, &cmd);
        mutex_unlock(&chan->shared_res->cmd_pending);

        /* start device */
        memset(&cmd, 0, sizeof(struct systec_cmd_msg));
        cmd.size = 8;
        cmd.cmd_data[0] = 1;
        cmd.cmd_data[6] = chan->chan_no;
        mutex_lock(&chan->shared_res->cmd_pending);
        ret_val = systec_can_send_cmd(chan->shared_res, &cmd);
        ret_val = systec_can_rcv_cmd_stat(chan->shared_res, &cmd);
        mutex_unlock(&chan->shared_res->cmd_pending);

        chan->can.state = CAN_STATE_ERROR_ACTIVE;

        chan->open_time = jiffies;

        netif_start_queue(netdev);

        return 0;
}

/*
  handler of status endpoint (interrupt endpoint)
*/
static void systec_can_read_stat_callback(struct urb *urb)
{
        struct systec_can_shared *shared_res = urb->context;
        struct systec_can_chan *chan;
        u32 mod_status;
/*
  todo:
        struct net_device *netdev = chan->netdev;
*/
        int ret_stat;

/*
  todo:
        if (!netif_device_present(netdev))
                return;
*/

        if (urb->status == 0) {
                mod_status = be32_to_cpu(*((u32*)urb->transfer_buffer));

                if (mod_status & 0x00000001) {
                        chan = shared_res->channels[1];
                }
                else {
                        chan = shared_res->channels[0];
                }

                /* clear channel number bit */
                mod_status &= 0xfffffffe;

                if (mod_status != chan->mod_status_int) {
                        /* channel status has been changed */
                        pr_debug("systec_can_read_stat_callback (%lu): %d, %x\n", jiffies,
                                urb->status, mod_status);
#if SYSTEC_DEBUG_STAT_CB
                        systec_dump_buf(urb->transfer_buffer, urb->actual_length);
#endif
                        /* update internal CAN status */
                        chan->mod_status_int = mod_status;

                        /* handle status */
                        systec_handle_status_change(chan, mod_status);
                }

                /* resubmit status urb */
                ret_stat = usb_submit_urb(urb, GFP_ATOMIC);
        }


/*
  todo: error to which device ?
        if (ret_stat == -ENODEV) {
                netif_device_detach(netdev);
        }
        else {
                if (ret_stat) {
                        netdev_err(netdev,
                        "failed resubmitting intr urb: %d\n", ret_stat);
                }
        }
*/

        return;

}


static void systec_handle_status_change(struct systec_can_chan *chan, u32 mod_status_int_new)
{
        struct can_frame *cf;
        struct sk_buff *skb;
        struct net_device_stats *stats = &chan->netdev->stats;
        enum can_state new_state;


#if SYSTEC_DEBUG_ERR_HANDLING
        netdev_dbg(chan->netdev, "systec_handle_status_change (%lu): %x\n", jiffies, chan->mod_status_int);
#endif

        /* convert device status into CAN state */
        if (mod_status_int_new & SYSTEC_CAN_STATE_ERR_BOFF) {
                new_state = CAN_STATE_BUS_OFF;
        }
        else {
                if (mod_status_int_new & SYSTEC_CAN_STATE_ERR_PASS) {
                        new_state = CAN_STATE_ERROR_PASSIVE;
                }
                else {
                        if (mod_status_int_new & SYSTEC_CAN_STATE_ERR_WARN) {
                                new_state = CAN_STATE_ERROR_WARNING;
                        }
                        else {
                                new_state = CAN_STATE_ERROR_ACTIVE;
/*
  todo: check other states
*/
                        }
                }
        }

#if SYSTEC_DEBUG_ERR_HANDLING
        netdev_dbg(chan->netdev, "   new_state: %x, current: %x\n", new_state, chan->can.state);
#endif
        if (new_state == chan->can.state)
        {
                netdev_warn(chan->netdev, "systec_handle_status_change: unknown status change 0x%X\n", mod_status_int_new);
                return;
        }

        /* alloc error frame */
        skb = alloc_can_err_skb(chan->netdev, &cf);
        if (unlikely(skb == NULL)) {
                return;
        }

        switch(chan->can.state) {
        case CAN_STATE_ERROR_ACTIVE:
                /* to ERROR_WARNING, ERROR_PASSIVE, BUS_OFF */
                if (new_state >= CAN_STATE_ERROR_WARNING && new_state <= CAN_STATE_BUS_OFF) {
                        chan->can.can_stats.error_warning++;

                        cf->can_id |= CAN_ERR_CRTL;
                        cf->data[1] = CAN_ERR_CRTL_TX_WARNING | CAN_ERR_CRTL_RX_WARNING;
                }

        case CAN_STATE_ERROR_WARNING:
                /* to ERROR_PASSIVE, BUS_OFF */
                if (new_state >= CAN_STATE_ERROR_PASSIVE && new_state <= CAN_STATE_BUS_OFF) {
                        chan->can.can_stats.error_passive++;

                        cf->can_id |= CAN_ERR_CRTL;
                        cf->data[1] = CAN_ERR_CRTL_TX_PASSIVE | CAN_ERR_CRTL_RX_PASSIVE;
                        chan->can.can_stats.error_passive++;
                }
                break;

        case CAN_STATE_BUS_OFF:
                /* to ERROR_ACTIVE, ERROR_WARNING, ERROR_PASSIVE */
                if (new_state <= CAN_STATE_ERROR_PASSIVE) {
                        cf->can_id |= CAN_ERR_RESTARTED;

                        chan->can.can_stats.restarts++;
                        netif_carrier_on(chan->netdev);
                        netif_wake_queue(chan->netdev);
                }
                break;

        default:
                break;
        }

        switch (new_state) {
        case CAN_STATE_ERROR_ACTIVE:
                cf->can_id |= CAN_ERR_PROT;
                cf->data[2] = CAN_ERR_PROT_ACTIVE;

                break;
        case CAN_STATE_BUS_OFF:
                cf->can_id |= CAN_ERR_BUSOFF;
                netif_carrier_off(chan->netdev);
                chan->can.can_stats.bus_off++;

                if (chan->can.restart_ms) {
                        /* schedule channel restart (will call can.do_set_mode) */
                        mod_timer(&chan->can.restart_timer,
                                jiffies + (chan->can.restart_ms * HZ) / 1000);
                }

        default:
                break;
        }

        chan->can.state = new_state;

        netif_rx(skb);
        stats->rx_packets++;
        stats->rx_bytes += cf->can_dlc;
}


#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 33)

static struct sk_buff *alloc_can_skb(struct net_device *dev, struct can_frame **cf)
{
	struct sk_buff *skb;

	skb = netdev_alloc_skb(dev, sizeof(struct can_frame));
	if (unlikely(!skb))
		return NULL;

	skb->protocol = htons(ETH_P_CAN);
	skb->pkt_type = PACKET_BROADCAST;
	skb->ip_summed = CHECKSUM_UNNECESSARY;
	*cf = (struct can_frame *)skb_put(skb, sizeof(struct can_frame));
	memset(*cf, 0, sizeof(struct can_frame));

	return skb;
}

static struct sk_buff *alloc_can_err_skb(struct net_device *dev, struct can_frame **cf)
{
        struct sk_buff *skb;

        skb = alloc_can_skb(dev, cf);
        if (unlikely(!skb))
                return NULL;

        (*cf)->can_id = CAN_ERR_FLAG;
        (*cf)->can_dlc = CAN_ERR_DLC;

        return skb;
}

#endif

static void systec_can_rx_can_msg(struct systec_can_chan *chan, u8 *msg_buf)
{
        struct can_frame *cf;
        struct sk_buff *skb;
        struct systec_can_msg *msg;
        int i;
        struct net_device_stats *stats = &chan->netdev->stats;

        skb = alloc_can_skb(chan->netdev, &cf);
        if (skb == NULL) {
                return;
        }

        msg = (struct systec_can_msg *)msg_buf;

        /* get size of data part of CAN message */
        cf->can_dlc = get_can_dlc(msg->format & USBCAN_DATAFF_DLC);

        cf->can_id = 0;

        if (msg->format & USBCAN_MSG_FF_RTR) {
                /* it is a RTR frame */
                cf->can_id |= CAN_RTR_FLAG;
        }
        else {
                if (msg->format & USBCAN_MSG_FF_EXT) {
                        /* copy data of an extended frame */
                        for (i = 0; i < cf->can_dlc; i++) {
                                cf->data[i] = msg->msg.can_ext_msg.data[i];
                        }

                }
                else {
                        /* copy data of a standard frame */
                        for (i = 0; i < cf->can_dlc; i++) {
                                cf->data[i] = msg->msg.can_std_msg.data[i];
                        }
                }
        }

        /* copy CAN ID */
        if (msg->format & USBCAN_MSG_FF_EXT) {
                /* extended frame */
                cf->can_id |= CAN_EFF_FLAG;

                cf->can_id |= be32_to_cpu(msg->msg.can_ext_msg.can_id) >> 3;
        }
        else {
                /* standard frame */
                cf->can_id |= (u32) (be16_to_cpu(msg->msg.can_std_msg.can_id) >> 5);
        }

        /* deliver frame to socket layer */
        netif_rx(skb);
        stats->rx_packets++;
        stats->rx_bytes += cf->can_dlc;
}

static void systec_can_read_data_callback(struct urb *urb)
{

        struct systec_can_shared *shared_res = urb->context;
        struct systec_can_chan *chan;
        struct net_device *netdev;
        int ret_stat;
        int total_size;
        u8 *msg_buf;
        struct systec_can_msg *msg;


#if SYSTEC_DEBUG_DATA_CB
        pr_debug("systec_can_read_data_callback (%lu): %d\n", jiffies, urb->status);
#endif

        if (urb->status == -ENOENT) {
                return;
        }

/*
  todo: error reporting - which device?
        if (urb->status != 0) {
                dev_info(netdev->dev.parent, "RX urb aborted, status: %d\n",
                         urb->status);
        }
*/

        if (urb->status == 0) {
#if SYSTEC_DEBUG_DATA_CB
                pr_debug("    message received: %d bytes\n", urb->actual_length);
#endif

                msg_buf = urb->transfer_buffer;
                total_size = urb->actual_length;
                while (total_size >= sizeof(struct systec_can_msg)) {

                        msg = (struct systec_can_msg *)msg_buf;
#if SYSTEC_DEBUG_BUFFER
                        systec_dump_msg_buf(msg_buf);
#endif

                        if (msg->format & USBCAN_DATAFF_CHANNEL1) {
                                if (shared_res->channels[1]) {
                                        chan = shared_res->channels[1];
                                }
                                else {
                                        pr_debug("received data for unavailable channel #2\n");
                                        /* take channel 0 */
                                        chan = shared_res->channels[0];
                                }
                        }
                        else {
                                chan = shared_res->channels[0];
                        }
                        netdev = chan->netdev;

                        if (netif_device_present(netdev)) {
                                systec_can_rx_can_msg(chan, msg_buf);
                        }

                        msg_buf += sizeof(struct systec_can_msg);
                        total_size -= sizeof(struct systec_can_msg);
                }
        }

        /* resubmit urb - use channel 0 since both channels use the same udev */
        chan = shared_res->channels[0];
        usb_fill_bulk_urb(urb, chan->shared_res->udev,
                          usb_rcvbulkpipe(chan->shared_res->udev, shared_res->endpoint_addresses[SYSTEC_EP_DATA_IN]),
                          urb->transfer_buffer, RX_BUFFER_SIZE,
                          systec_can_read_data_callback, shared_res);

        ret_stat = usb_submit_urb(urb, GFP_ATOMIC);

/*
  todo: which device should fail?

        if (ret_stat == -ENODEV) {
                netif_device_detach(netdev);
        }
        else {
                if (ret_stat) {
                        netdev_err(netdev,
                                "failed resubmitting read bulk urb: %d\n", ret_stat);
                }
        }
*/

        return;
}

static int systec_can_close(struct net_device *netdev)
{
        struct systec_can_chan *chan = netdev_priv(netdev);
        struct systec_cmd_msg cmd;
        int ret_val;

        netdev_dbg(netdev, "systec_can_close: channel %d\n", chan->chan_no);

        /* stop channel */
        memset(&cmd, 0, sizeof(struct systec_cmd_msg));
        cmd.size = 8;
        cmd.cmd_data[0] = USBCAN_CMD_SHUTDOWN;
        cmd.cmd_data[6] = chan->chan_no;
        ret_val = systec_can_send_cmd(chan->shared_res, &cmd);
        ret_val = systec_can_rcv_cmd_stat(chan->shared_res, &cmd);

        /* stop polling tx */
        systec_unlink_urbs(chan);

        netif_stop_queue(netdev);

        mutex_lock(&chan->shared_res->lock_shared);

        if (chan->shared_res->intr_urb_running == 1) {
                /* this is the only running channel - stop status urb */
                usb_unlink_urb(chan->shared_res->intr_urb);

                chan->shared_res->intr_urb_running = 0;

                netdev_dbg(netdev, "systec_can_close: intr_urb stoped\n");
        }
        else {
                /* one channel is still running */
                chan->shared_res->intr_urb_running = 1;

                netdev_dbg(netdev, "systec_can_close: intr_urb still running\n");
        }

        if (chan->shared_res->rx_urb_running == 1) {
               /* this is the only running channel - stop rx urb */
                usb_kill_anchored_urbs(&chan->shared_res->rx_submitted);

                chan->shared_res->rx_urb_running = 0;

                netdev_dbg(netdev, "systec_can_close: rx_urb stoped\n");
        }
        else {
                /* one channel is still running */
                chan->shared_res->rx_urb_running = 1;

                netdev_dbg(netdev, "systec_can_close: rx_urb still running\n");
        }

        mutex_unlock(&chan->shared_res->lock_shared);

        close_candev(netdev);

        chan->open_time = 0;

        return 0;
}

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 34)
static inline int can_dropped_invalid_skb(struct net_device *dev,
					  struct sk_buff *skb)
{
	const struct can_frame *cf = (struct can_frame *)skb->data;

	if (unlikely(skb->len != sizeof(*cf) || cf->can_dlc > 8)) {
		kfree_skb(skb);
		dev->stats.tx_dropped++;
		return 1;
	}

	return 0;
}
#endif

static netdev_tx_t systec_can_start_xmit(struct sk_buff *skb, struct net_device *netdev)
{
        struct systec_can_chan *chan = netdev_priv(netdev);
        struct systec_tx_urb_context *context = NULL;
        struct net_device_stats *stats = &netdev->stats;
        struct can_frame *cf = (struct can_frame *)skb->data;
        struct systec_can_msg *msg;
        struct urb *tx_urb;
        u8 *buf;
        int i;
        int ret_val;

        if (can_dropped_invalid_skb(netdev, skb)) {
                return NETDEV_TX_OK;
        }

#if SYSTEC_DEBUG_TX
        dev_dbg(&intf->dev, "systec_can_start_xmit (%lu)\n", jiffies);
#endif

        /* create the tx urb */
        tx_urb = usb_alloc_urb(0, GFP_ATOMIC);
        if (!tx_urb) {
                netdev_err(netdev, "not enough memory to create tx_urb\n");

                dev_kfree_skb(skb);
                stats->tx_dropped++;
                return(NETDEV_TX_OK);
        }

        /* create the buffer for the CAN message */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 34)
        buf = usb_alloc_coherent(chan->shared_res->udev, sizeof(struct systec_can_msg),
                               GFP_ATOMIC, &tx_urb->transfer_dma);
#else
        buf = usb_buffer_alloc(chan->shared_res->udev, sizeof(struct systec_can_msg),
                               GFP_ATOMIC, &tx_urb->transfer_dma);
#endif
        if (!buf) {
                netdev_err(netdev, "not enough memory to create tx buffer\n");

                usb_free_urb(tx_urb);
                dev_kfree_skb(skb);
                stats->tx_dropped++;
                return(NETDEV_TX_OK);
        }

        /* map internal CAN message to buffer */
        msg = (struct systec_can_msg *)buf;

        /* set DLC */
        msg->format = cf->can_dlc;

        /* set channel number */
        if (chan->chan_no == 1) {
                /* set bit for channel 1 */
                msg->format |= USBCAN_DATAFF_CHANNEL1;
        }

        /* set CAN ID */
        if (cf->can_id & CAN_EFF_FLAG) {
                msg->msg.can_ext_msg.can_id = cpu_to_be32((cf->can_id & CAN_ERR_MASK) << 3);
                msg->format |= USBCAN_MSG_FF_EXT;
        }
        else {
                msg->msg.can_std_msg.can_id = cpu_to_be16((u16)(cf->can_id & CAN_ERR_MASK) << 5);
        }

        if (cf->can_id & CAN_RTR_FLAG) {
                msg->format |= USBCAN_MSG_FF_RTR;
        }
        else {
                if (cf->can_id & CAN_EFF_FLAG) {
                        for (i = 0; i < cf->can_dlc; i++) {
                                msg->msg.can_ext_msg.data[i] = cf->data[i];
                        }
                }
                else {
                        for (i = 0; i < cf->can_dlc; i++) {
                                msg->msg.can_std_msg.data[i] = cf->data[i];
                        }
                }
        }

        /* look for an available context */
        for (i = 0; i < MAX_TX_URBS; i++) {
                if (chan->tx_contexts[i].echo_index == MAX_TX_URBS) {
                        context = &chan->tx_contexts[i];
                        break;
                }
        }

        if (!context)
        {
                /* oops, more URBs than allowed */
                usb_unanchor_urb(tx_urb);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 34)
                usb_free_coherent(chan->shared_res->udev, sizeof(struct systec_can_msg),
                                buf, tx_urb->transfer_dma);
#else
                usb_buffer_free(chan->shared_res->udev, sizeof(struct systec_can_msg),
                                buf, tx_urb->transfer_dma);
#endif

                dev_warn(netdev->dev.parent, "all contexts are in use\n");
                return(NETDEV_TX_BUSY);
        }

#if SYSTEC_DEBUG_BUFFER
        systec_dump_msg_buf(buf);
#endif

        context->chan = chan;
        context->echo_index = i;
        context->dlc = cf->can_dlc;

        usb_fill_bulk_urb(tx_urb, chan->shared_res->udev,
                          usb_sndbulkpipe(chan->shared_res->udev,
                                          chan->shared_res->endpoint_addresses[SYSTEC_EP_DATA_OUT]),
                          buf,
                          sizeof(struct systec_can_msg),
                          systec_can_write_data_callback, context);

        tx_urb->transfer_flags |= URB_NO_TRANSFER_DMA_MAP;
        usb_anchor_urb(tx_urb, &chan->tx_submitted);

        can_put_echo_skb(skb, netdev, context->echo_index);

        atomic_inc(&chan->active_tx_urbs);

        ret_val = usb_submit_urb(tx_urb, GFP_ATOMIC);

        /* prefer else part */
        if(unlikely(ret_val)) {
                can_free_echo_skb(netdev, context->echo_index);

                usb_unanchor_urb(tx_urb);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 34)
                usb_free_coherent(chan->shared_res->udev, sizeof(struct systec_can_msg),
                                buf, tx_urb->transfer_dma);
#else
                usb_buffer_free(chan->shared_res->udev, sizeof(struct systec_can_msg),
                                buf, tx_urb->transfer_dma);
#endif
                dev_kfree_skb(skb);

                atomic_dec(&chan->active_tx_urbs);

                if (ret_val == -ENODEV) {
                        netif_device_detach(netdev);
                } else {
                        dev_warn(netdev->dev.parent, "failed tx_urb %d\n", ret_val);

                        stats->tx_dropped++;
                }
        }
        else {
                netdev->trans_start = jiffies;

                if (atomic_read(&chan->active_tx_urbs) >= MAX_TX_URBS) {
                        /* slow down transmitting frames */
                        netif_stop_queue(netdev);
                }
        }

        usb_free_urb(tx_urb);

        return NETDEV_TX_OK;
}

static void systec_can_write_data_callback(struct urb *urb)
{
        struct systec_tx_urb_context *context = urb->context;
        struct systec_can_chan *chan;
        struct net_device *netdev;

        BUG_ON(!context);

#if SYSTEC_DEBUG_TX
        netdev_dbg(netdev, "systec_can_write_data_callback (%lu)\n", jiffies);
#endif

        chan = context->chan;
        netdev = chan->netdev;

        /* free the buffer of CAN message */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 34)
        usb_free_coherent(urb->dev, urb->transfer_buffer_length,
                        urb->transfer_buffer, urb->transfer_dma);
#else
        usb_buffer_free(urb->dev, urb->transfer_buffer_length,
                        urb->transfer_buffer, urb->transfer_dma);
#endif

        /* the urb is not active any more */
        atomic_dec(&chan->active_tx_urbs);

        if (!netif_device_present(netdev))
                return;

        if (urb->status)
                dev_info(netdev->dev.parent, "tx urb aborted (%d)\n",
                         urb->status);

        netdev->trans_start = jiffies;

        /* interface statistics */
        netdev->stats.tx_packets++;
        netdev->stats.tx_bytes += context->dlc;

        can_get_echo_skb(netdev, context->echo_index);

        /* mark context as free */
        context->echo_index = MAX_TX_URBS;

        /* check if the queue has been stopped */
        if (netif_queue_stopped(netdev))
                netif_wake_queue(netdev);

}

static int systec_can_set_bittiming(struct net_device *netdev)
{
        struct systec_can_chan *chan = netdev_priv(netdev);
        struct can_bittiming *bt = &chan->can.bittiming;
        struct systec_cmd_msg cmd;
        int ret_val;
        u32 baud_ex_reg;

#if SYSTEC_DEBUG_BITTIMING
        netdev_dbg(netdev, "systec_can_set_bittiming (#%d)\n",
               (int)chan->chan_no);

        netdev_dbg(netdev, "  bitrate: %d\n", bt->bitrate);
        netdev_dbg(netdev, "  sample_point: %x\n", bt->sample_point);
        netdev_dbg(netdev, "  tq: %x\n", bt->tq);
        netdev_dbg(netdev, "  prop_seg: %x\n", bt->prop_seg);
        netdev_dbg(netdev, "  phase_seg1: %x\n", bt->phase_seg1);
        netdev_dbg(netdev, "  phase_seg2: %x\n", bt->phase_seg2);
        netdev_dbg(netdev, "  sjw: %x\n", bt->sjw);
        netdev_dbg(netdev, "  brp: %x\n", bt->brp);
#endif /* SYSTEC_DEBUG_BITTIMING */

        /* set PHASE2 */
        baud_ex_reg = (bt->phase_seg2 - 1) & 0x7;

        /* set PHASE1 */
        baud_ex_reg |= ((bt->phase_seg1 - 1) & 0x7) << 4;

        /* set PROPAG */
        baud_ex_reg |= ((bt->prop_seg - 1) & 0x7) << 8;

        /* set BPR */
/*
  todo: what happens if bt->brp is 0x80
*/
        if (bt->brp & 0x80) {
                /* use additional clock devider */
                baud_ex_reg |= (((bt->brp >> 1) - 1) & 0x7f) << 16;

                baud_ex_reg |= 0x80000000;
        }
        else
        {
                /* do no use additional clock devider */
                baud_ex_reg |= ((bt->brp - 1) & 0x7f) << 16;
        }

        if (chan->can.ctrlmode & CAN_CTRLMODE_3_SAMPLES) {
                /* set SAM */
                baud_ex_reg |= 0x01000000;
        }

#if SYSTEC_DEBUG_BITTIMING
        netdev_dbg(netdev, "  baud_ex_reg: %x\n", baud_ex_reg);
#endif /* SYSTEC_DEBUG_BITTIMING */

        ret_val = 0;
        memset(&cmd, 0, sizeof(struct systec_cmd_msg));

        cmd.size = SYSTEC_CMD_SIZE;
        cmd.cmd_data[0] = USBCAN_CMD_SETBAUDRATE_EX;
        cmd.cmd_data[6] = chan->chan_no;

        *((__le32 *) &cmd.cmd_data[1]) = cpu_to_le32(baud_ex_reg);

        /* save bittiming */
        chan->baud_ex_reg = baud_ex_reg;

        mutex_lock(&chan->shared_res->cmd_pending);
        ret_val = systec_can_send_cmd(chan->shared_res, &cmd);
        ret_val = systec_can_rcv_cmd_stat(chan->shared_res, &cmd);
        mutex_unlock(&chan->shared_res->cmd_pending);
/*
todo: check ret_val, move commands to proper function
*/


        return(ret_val);
}

static int systec_get_serial_no(struct systec_can_shared *shared_res)
{
        struct systec_cmd_msg cmd;
        int ret_val;
        int i;

        /* get serial number */
        for (i = 0; i < 4; i++) {
                memset(&cmd, 0, sizeof(struct systec_cmd_msg));
                cmd.size = 8;
                cmd.cmd_data[0] = USBCAN_CMD_READEEPROM;
                cmd.cmd_data[1] = USBCAN_EEPROM_SERIALNR + i;
                ret_val = systec_can_send_cmd(shared_res, &cmd);
                ret_val = systec_can_rcv_cmd_stat(shared_res, &cmd);

                shared_res->serial_no[i] = cmd.cmd_data[2];
        }


        /* get device number */
        memset(&cmd, 0, sizeof(struct systec_cmd_msg));
        cmd.size = 8;
        cmd.cmd_data[0] = USBCAN_CMD_READEEPROM;
        cmd.cmd_data[1] = USBCAN_EEPROM_DEVICENR;
        ret_val = systec_can_send_cmd(shared_res, &cmd);
        ret_val = systec_can_rcv_cmd_stat(shared_res, &cmd);

        shared_res->device_no = cmd.cmd_data[2];

        return(0);
}

static int systec_dual_chan_device(struct systec_can_shared *shared_res)
{
        struct systec_cmd_msg cmd;
        int ret_val;
        u16 product_id;

        memset(&cmd, 0, sizeof(struct systec_cmd_msg));
        cmd.size = 8;
        cmd.cmd_data[0] = USBCAN_CMD_READEEPROM;
        cmd.cmd_data[1] = USBCAN_EEPROM_PID;
        ret_val = systec_can_send_cmd(shared_res, &cmd);
        ret_val = systec_can_rcv_cmd_stat(shared_res, &cmd);

/*
todo: check ret_val
*/

        product_id = (u16)cmd.cmd_data[2];

        memset(&cmd, 0, sizeof(struct systec_cmd_msg));
        cmd.size = 8;
        cmd.cmd_data[0] = USBCAN_CMD_READEEPROM;
        cmd.cmd_data[1] = USBCAN_EEPROM_PID + 1;
        ret_val = systec_can_send_cmd(shared_res, &cmd);
        ret_val = systec_can_rcv_cmd_stat(shared_res, &cmd);

        product_id |= ((u16)cmd.cmd_data[2] << 8);

        if (product_id != 0) {
            /* Bit 0 of product ID is set, if it's a dual channel device */
            return (product_id & 0x0001);
        }

//        netdev_err(chan->netdev, "product id %x unknown (code %d)\n", product_id, ret_val);
        /* assume single channel device */
        return(0);
}

static int systec_can_set_mode(struct net_device *netdev, enum can_mode mode)
{
        struct systec_can_chan *chan;

        chan = netdev_priv(netdev);

        netdev_dbg(netdev, "systec_can_set_mode: %d\n", (int)mode);

        if (!chan->open_time) {
                /* channel is not open */
                return(-EINVAL);
        }

        switch (mode) {
        case CAN_MODE_START:
                /* schedule restart of the channel */
                queue_work(cmd_wq, &chan->restart_work.work);

                break;

        default:
                return(-EOPNOTSUPP);
        }

        return 0;
}

static void systec_work_chan_restart(struct work_struct *work)
{
        struct systec_work *chan_work;
        struct systec_can_chan *chan;
        struct systec_cmd_msg cmd;
        int ret_val;

        chan_work = container_of(work, struct systec_work, work);
        chan = chan_work->chan;

        mutex_lock(&chan->shared_res->cmd_pending);

#if SYSTEC_DEBUG_ERR_HANDLING
        netdev_dbg(chan->netdev, "systec_work_chan_restart\n");
#endif

        /* reset channel */
        memset(&cmd, 0, sizeof(struct systec_cmd_msg));
        cmd.size = 8;
        cmd.cmd_data[0] = USBCAN_CMD_RESET;
        cmd.cmd_data[4] = 0xff;
        cmd.cmd_data[5] = 0xfd;
        cmd.cmd_data[6] = chan->chan_no;
        ret_val = systec_can_send_cmd(chan->shared_res, &cmd);
        ret_val = systec_can_rcv_cmd_stat(chan->shared_res, &cmd);

        /* start channel */
        memset(&cmd, 0, sizeof(struct systec_cmd_msg));
        cmd.size = 8;
        cmd.cmd_data[0] = 1;
        cmd.cmd_data[6] = chan->chan_no;
        ret_val = systec_can_send_cmd(chan->shared_res, &cmd);
        ret_val = systec_can_rcv_cmd_stat(chan->shared_res, &cmd);

        mutex_unlock(&chan->shared_res->cmd_pending);

        if (netif_queue_stopped(chan->netdev)) {
                netif_wake_queue(chan->netdev);
        }

        return;
}

static void systec_unlink_urbs(struct systec_can_chan *chan)
{
        int i;


        usb_kill_anchored_urbs(&chan->tx_submitted);
        atomic_set(&chan->active_tx_urbs, 0);

        for (i = 0; i < MAX_TX_URBS; i++)
                chan->tx_contexts[i].echo_index = MAX_TX_URBS;
}

static int systec_can_send_cmd(struct systec_can_shared *shared_res, struct systec_cmd_msg *msg)
{
        int actual_length;
        int ret_stat;

        /* copy command to be sent */
        memcpy(&shared_res->tx_cmd_buffer[0], &msg->cmd_data[0], msg->size);

#if SYSTEC_DEBUG_CMD
        dev_dbg(&intf->dev, "systec_can_send_cmd\n");
#endif
#if SYSTEC_DEBUG_BUFFER
        systec_dump_cmd_buf(shared_res->tx_cmd_buffer);
#endif

        /* send command */
        ret_stat =  usb_bulk_msg(shared_res->udev,
                                usb_sndbulkpipe(shared_res->udev,
                                                shared_res->endpoint_addresses[SYSTEC_EP_MSG_OUT]),
                                &shared_res->tx_cmd_buffer[0],
                                msg->size,
                                &actual_length, SYSTEC_BULK_TIMEOUT);

#if SYSTEC_DEBUG_CMD
        dev_dbg(&intf->dev, "systec_can_send_cmd: %d, %d\n",
               actual_length, ret_stat);
#endif

        return (ret_stat);
}

static int systec_can_rcv_cmd_stat(struct systec_can_shared *shared_res, struct systec_cmd_msg *msg)
{
        int actual_length;
        int ret_stat;

        /* get command status  */
        ret_stat =  usb_bulk_msg(shared_res->udev,
                                usb_rcvbulkpipe(shared_res->udev,
                                                shared_res->endpoint_addresses[SYSTEC_EP_MSG_IN]),
                                &shared_res->rx_cmd_buffer[0],
                                msg->size,
                                &actual_length, SYSTEC_BULK_TIMEOUT);

#if SYSTEC_DEBUG_CMD
        dev_dbg(&intf->dev, "systec_can_rcv_cmd_stat: %d, %d\n",
               actual_length, ret_stat);
#endif
#if SYSTEC_DEBUG_BUFFER
        systec_dump_cmd_buf(shared_res->rx_cmd_buffer);
#endif

        memcpy(&msg->cmd_data[0], &shared_res->rx_cmd_buffer[0], actual_length);

        return (ret_stat);

}

#if SYSTEC_DEBUG_BUFFER
static void systec_dump_cmd_buf(u8 *buffer)
{
  dev_dbg(&intf->dev, "  buffer: %.2x %.2x %.2x %.2x %.2x %.2x %.2x %.2x\n",
        buffer[0], buffer[1], buffer[2], buffer[3], buffer[4], buffer[5], buffer[6], buffer[7]);
}

static void systec_dump_msg_buf(u8 *buffer)
{
  dev_dbg(&intf->dev, "  buffer: %.2x %.2x %.2x %.2x %.2x %.2x %.2x %.2x %.2x %.2x %.2x %.2x %.2x %.2x %.2x %.2x\n",
        buffer[0], buffer[1], buffer[2], buffer[3], buffer[4], buffer[5], buffer[6], buffer[7],
        buffer[8], buffer[9], buffer[10], buffer[11], buffer[12], buffer[13], buffer[14], buffer[15]);
}
#endif

#if SYSTEC_DEBUG_STAT_CB
static void systec_dump_buf(u8 *buffer, int size)
{
        char print_buf[6 + 3 * 16 + 2];
        int i;
        char val;

        print_buf[0] = ' ';
        print_buf[1] = ' ';
        print_buf[2] = 'b';
        print_buf[3] = 'u';
        print_buf[4] = 'f';
        print_buf[5] = ':';

        if (size > 16) {
                size = 16;
        }

        i = 6;
        while (size) {
                print_buf[i] = ' ';
                i++;
                val = *buffer >> 4;
                if (val < 10) {
                        print_buf[i] = val + '0';
                }
                else {
                        print_buf[i] = val - 10 + 'a';
                }
                i++;

                val = *buffer & 0x0f;
                if (val < 10) {
                        print_buf[i] = val + '0';
                }
                else {
                        print_buf[i] = val - 10 + 'a';
                }
                i++;

                size--;
                buffer++;
        }
        print_buf[i] = '\n';
        i++;
        print_buf[i] = '\0';

        printk(print_buf);
}
#endif

static int systec_can_update_firmware(struct usb_interface *intf,
                            const struct firmware *fw,
                            u16 current_product_id,
                            u32 required_fw_version)
{
        int ret_stat;
        struct usb_device *udev;
        struct device *dev = &intf->dev;
        struct intel_hex_record *fw_record;
        int download_size;
        int count;
        u16 product_id;
        u32 current_version;
        u8 *buffer;
        u32 update_buf[3];

        udev = interface_to_usbdev(intf);

        fw_record = (struct intel_hex_record *)fw->data;

        if (fw_record->type != HEX_RECORD_TYPE_HEADER
                || fw_record->address != 0)
        {
                dev_err(dev, "could not find firmware header");
                return(-ENODEV);
        }

        /* get header version - currently no further actions are required */
        current_version = le32_to_cpup((__le32*)&fw_record->data[0]);
        dev_dbg(dev, "   found firmware header version: %d.%d r%d",
                GETPC_MAJOR_VER(current_version),
                GETPC_MINOR_VER(current_version),
                GETPC_RELEASE_VER(current_version));

        /* get version of firmware image */
        current_version = le32_to_cpup((__le32*)&fw_record->data[4]);
        if (current_version != required_fw_version) {
                dev_err(dev, "wrong firmware version %d.%d r%d (required is %d.%d r%d)",
                        GETPC_MAJOR_VER(current_version),
                        GETPC_MINOR_VER(current_version),
                        GETPC_RELEASE_VER(current_version),
                        GETPC_MAJOR_VER(required_fw_version),
                        GETPC_MINOR_VER(required_fw_version),
                        GETPC_RELEASE_VER(required_fw_version));

                return(-ENODEV);
        }

        /* get product id of firmware image */
        product_id = le16_to_cpup((__le16*)&fw_record->data[8]);
        if (product_id != current_product_id) {
                dev_err(dev, "wrong firmware product id %.4x (device product id is %.4x)",
                        product_id, current_product_id);

                return(-ENODEV);
        }

        fw_record++;

        /* start update */
        ret_stat = usb_control_msg(udev,
                                usb_sndctrlpipe (udev, 0),
                                USBCAN_VRREQ_START_UPDATE,
                                USB_DIR_OUT | USB_TYPE_VENDOR | USB_RECIP_DEVICE,
                                0, 0, NULL, 0, SYSTEC_BULK_TIMEOUT);
        if (ret_stat < 0) {
                dev_err(dev, "could not prepare device for firmware upload (code %d)",
                                ret_stat);
                return(-ENODEV);
        }

        buffer = kmalloc(sizeof(struct intel_hex_record), GFP_KERNEL);
        if (buffer == NULL) {
                dev_err(dev, "could not alloc buffer to upload firmware");
                return(-ENOMEM);
        }

        count = 0;
        download_size = 0;
        while (fw_record->type != 1 && download_size < fw->size) {
                memcpy(buffer, fw_record, sizeof(struct intel_hex_record));

                /* send record to CAN device */
                ret_stat = usb_control_msg(udev,
                                        usb_sndctrlpipe (udev, 0),
                                        USBCAN_VRREQ_WRITE_UPDATE,
                                        USB_DIR_OUT | USB_TYPE_VENDOR | USB_RECIP_DEVICE,
                                        0, 0, buffer,
                                        sizeof(fw_record->type) + sizeof(fw_record->length)
                                        + sizeof(fw_record->address) + fw_record->length,
                                        SYSTEC_BULK_TIMEOUT);

                if (ret_stat < 0) {
                        dev_err(dev, "firmware update failed at address: 0x%x, code: %d",
                                fw_record->address, ret_stat);

                        kfree(buffer);
                        return(-ENODEV);
                }

                fw_record++;
                count++;
                download_size += sizeof(struct intel_hex_record);
        }

        kfree(buffer);

        if (download_size >= fw->size) {
                /* should never happen (intel hex record eof not found) */
                dev_err(dev, "intel hex record eof not found");
                return(-ENODEV);
        }

        dev_dbg(&intf->dev, "%d firmware records uploaded", count);

        /* check update status */
        ret_stat = usb_control_msg(udev,
                                usb_rcvctrlpipe (udev, 0),
                                USBCAN_VRREQ_CHECK_UPDATE,
                                USB_DIR_IN | USB_TYPE_VENDOR | USB_RECIP_DEVICE,
                                0, 0, update_buf, sizeof(update_buf),
                                SYSTEC_BULK_TIMEOUT);

        if (ret_stat != sizeof(update_buf)) {
                dev_warn(dev, "could not check update result (code %d)",
                        ret_stat);
                return(-ENODEV);
        }

        /* stop update */
        if (le32_to_cpu(update_buf[0]) == 0) {
                dev_dbg(dev, "stopping update");
                ret_stat = usb_control_msg(udev,
                                        usb_sndctrlpipe (udev, 0),
                                        USBCAN_VRREQ_STOPP_UPDATE,
                                        USB_DIR_OUT | USB_TYPE_VENDOR | USB_RECIP_DEVICE,
                                        0, 0, NULL, 0, SYSTEC_BULK_TIMEOUT);

                if (ret_stat < 0) {
                        dev_err(dev, "could not stop update (code %d)",
                                ret_stat);
                        return(-ENODEV);
                }

                /* write firmware to flash */
                dev_dbg(dev, "writing firmware to flash");
                update_buf[0] = cpu_to_le32(USBCAN_ADDRESS_FIRMWARE);
                update_buf[1] = cpu_to_le32(USBCAN_UPDATE_BUFFER_SIZE);
                update_buf[2] = 0;

                ret_stat = usb_control_msg(udev,
                                        usb_sndctrlpipe (udev, 0),
                                        USBCAN_VRREQ_WRITE_FLASH,
                                        USB_DIR_OUT | USB_TYPE_VENDOR | USB_RECIP_DEVICE,
                                        0, 0, update_buf, sizeof(update_buf),
                                        SYSTEC_BULK_TIMEOUT);

                if (ret_stat < 0) {
                        dev_err(dev, "could not write firmware to flash (code %d)",
                                ret_stat);
                        return(-ENODEV);
                }

        }
        else {
                dev_err(dev, "update failed (device returned 0x%x 0x%x)",
                        le32_to_cpu(update_buf[0]), le32_to_cpu(update_buf[1]));
                return(-ENODEV);
        }

        return (0);
}

static int systec_can_main_probe_boot(struct usb_interface *intf,
                            const struct usb_device_id *id)
{
        int ret_stat;
        __le32 data;
        u32 current_version;
        struct usb_device *udev;
        const struct firmware *fw;
        struct device *dev = &intf->dev;
        int count;
        __le32 update_buf[3];
        const char *fw_name_template = FIRMWARE_NAME;
        char *fw_name;
        u32 required_fw_version;

        dev_dbg(dev, "systec_can_main_probe_boot\n");

        /* indicate that CAN device is in boot mode */
        usb_set_intfdata(intf, NULL);

        udev = interface_to_usbdev(intf);

        /* get required firmware version based on product id */
        count = 0;
        while (systec_pid_chan_table[count].pid != 0
                && id->idProduct != systec_pid_chan_table[count].pid) {

                count++;
        }

        if (systec_pid_chan_table[count].pid == 0) {
                /* should never happen */
                dev_err(dev, "   unknown product id 0x%x", id->idProduct);

                return(-ENODEV);
        }

        required_fw_version = systec_pid_chan_table[count].required_fw_version;

        current_version = 0;

        /* read firmware version from device */
        ret_stat = usb_control_msg (udev,
                                    usb_rcvctrlpipe (udev, 0),
                                    USBCAN_VRREQ_READ_FW_VERSION,
                                    USB_DIR_IN | USB_TYPE_VENDOR | USB_RECIP_DEVICE,
                                    0,
                                    0,
                                    &data,
                                    sizeof (data),
                                    SYSTEC_BULK_TIMEOUT);

        if (ret_stat != sizeof (data)) {
                dev_err(dev, "could not read firmware version from device (code %d)",
                        ret_stat);
                dev_err(dev, "It seems that no bootloader is present on this device. Contact vendor for support.");
                return(-ENODEV);
        }

        current_version = le32_to_cpu(data);

        dev_info(dev, "device firmware version: %d.%d r%d",
                GETPC_MAJOR_VER(current_version),GETPC_MINOR_VER(current_version),
                GETPC_RELEASE_VER(current_version));
        dev_dbg(dev, "version required by driver: %d.%d r%d",
                GETPC_MAJOR_VER(required_fw_version),GETPC_MINOR_VER(required_fw_version),
                GETPC_RELEASE_VER(required_fw_version));

        if (current_version == required_fw_version) {

                dev_dbg(dev, "   firmware of device is up to date");

                /* ceck crc of firmware */
                update_buf[0] = cpu_to_le32(USBCAN_ADDRESS_FIRMWARE);
                update_buf[1] = cpu_to_le32(USBCAN_UPDATE_BUFFER_SIZE);

                ret_stat = usb_control_msg(udev,
                                        usb_sndctrlpipe (udev, 0),
                                        USBCAN_VRREQ_CHECK_CRC,
                                        USB_DIR_OUT | USB_TYPE_VENDOR | USB_RECIP_DEVICE,
                                        0, 0, update_buf, 2 * sizeof(update_buf[0]),
                                        SYSTEC_BULK_TIMEOUT);

                if (ret_stat < 0) {
                        dev_err(dev, "could not run crc check (code %d)",
                                ret_stat);
                        return(-ENODEV);
                }

                /* get result of crc check */
                memset(update_buf, 0, sizeof(update_buf));
                ret_stat = usb_control_msg(udev,
                                        usb_rcvctrlpipe (udev, 0),
                                        USBCAN_VRREQ_GET_CRC_RESULT,
                                        USB_DIR_IN | USB_TYPE_VENDOR | USB_RECIP_DEVICE,
                                        0, 0, update_buf, sizeof(update_buf),
                                        SYSTEC_BULK_TIMEOUT);

                if (ret_stat != sizeof(update_buf)) {
                        dev_err(dev, "could not get result of crc check (code %d)",
                                ret_stat);
                        return(-ENODEV);
                }

                if (le32_to_cpu(update_buf[0]) == 0) {

                        dev_dbg(dev, "   firmware crc check passed");

                        /* boot CAN device via reconnect */
                        ret_stat = usb_control_msg (udev,
                                                usb_sndctrlpipe (udev, 0),
                                                USBCAN_VRREQ_RECONNECT,
                                                USB_DIR_OUT | USB_TYPE_VENDOR | USB_RECIP_DEVICE,
                                                0, 0, NULL, 0, SYSTEC_BULK_TIMEOUT);
                        return 0;
                }

                dev_info(dev, "firmware crc check failed (ErrorCode=0x%08X, CryptCrc32=0x%08X, StartMode=0x%08X)",
                        le32_to_cpu(update_buf[0]),
                        le32_to_cpu(update_buf[1]),
                        le32_to_cpu(update_buf[2]));

                /* continue with download of firmware, because CRC check failed */
        }

        /* create name of firmware image */
        fw_name = kmalloc(strlen(fw_name_template) + 16, GFP_KERNEL);
        if (!fw_name) {
                dev_err(dev, "could not alloc buffer to create firmware name");
                return(-ENOMEM);
        }

        sprintf(fw_name, fw_name_template,
                (u16)id->idProduct,
                (u8)GETPC_MAJOR_VER(required_fw_version),
                (u8)GETPC_MINOR_VER(required_fw_version),
                (u16)GETPC_RELEASE_VER(required_fw_version));

        dev_info(dev, "request firmware image: %s", fw_name);

        /* request firmware */
        if (request_firmware(&fw, fw_name, dev) == 0) {

                kfree(fw_name);

                dev_dbg(dev, "request_firmware: %zd bytes", fw->size);

                ret_stat = systec_can_update_firmware(intf, fw, id->idProduct, required_fw_version);
                release_firmware(fw);
                if (ret_stat != 0)
                {
                        return ret_stat;
                }

        }
        else {
                dev_err(dev, "firmware request failed (%s)", fw_name);
                kfree(fw_name);

                return(-ENODEV);
        }

        return 0;
}


static void systec_can_free_channel(struct usb_interface *intf,
                            struct systec_can_shared *shared_res,
                            int chan_no)
{
    if (shared_res->channels[chan_no]) {
#if SYSTEC_DEBUG_USB_DISCONNECT
            dev_dbg(&intf->dev, "  usb_kill_anchored_urbs (tx_submitted, channel %d)\n", chan_no);
#endif
            usb_kill_anchored_urbs(&shared_res->channels[chan_no]->tx_submitted);

            dev_info(&intf->dev, "unregister device: %s (channel %d)\n", shared_res->channels[chan_no]->netdev->name, chan_no);
            unregister_netdev(shared_res->channels[chan_no]->netdev);

#if SYSTEC_DEBUG_USB_DISCONNECT
            dev_dbg(&intf->dev, "  free_candev (channel %d)\n", chan_no);
#endif
            free_candev(shared_res->channels[chan_no]->netdev);
            shared_res->channels[chan_no] = NULL;
    }
}


static int systec_can_alloc_channel(struct usb_interface *intf,
                            struct systec_can_shared *shared_res,
                            int chan_no)
{
        int ret_stat = -ENOMEM;
        struct net_device *netdev;
        struct systec_can_chan *chan;
        int i;

        /* prepare channel 1 */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 33)
        netdev = alloc_candev(sizeof(struct systec_can_chan), MAX_TX_URBS);
#else
        netdev = alloc_candev(sizeof(struct systec_can_chan));
#endif
        if (!netdev) {
                dev_err(&intf->dev, "Couldn't alloc candev for channel %d\n",
                        chan_no);

                return(-ENOMEM);
        }

        /* get private part */
        chan = netdev_priv(netdev);

        shared_res->channels[chan_no] = chan;

        chan->netdev = netdev;
        chan->chan_no = chan_no;
        chan->mod_status_int = 0;

        /* init CAN parameters */
        chan->can.state = CAN_STATE_STOPPED;
        chan->can.clock.freq = SYSTEC_DEVICE_CLOCK;
        chan->can.bittiming_const = &systec_can_bittiming_const;
        chan->can.do_set_bittiming = systec_can_set_bittiming;
        chan->can.do_set_mode = systec_can_set_mode;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 34)
        chan->can.ctrlmode_supported = CAN_CTRLMODE_3_SAMPLES |
                                      CAN_CTRLMODE_LOOPBACK |
                                      CAN_CTRLMODE_LISTENONLY;
#endif

        netdev->netdev_ops = &systec_can_netdev_ops;

        /* support local echo */
        netdev->flags |= IFF_ECHO;

        for (i = 0; i < MAX_TX_URBS; i++) {
                chan->tx_contexts[i].echo_index = MAX_TX_URBS;
        }

        init_usb_anchor(&chan->tx_submitted);
        atomic_set(&chan->active_tx_urbs, 0);

        SET_NETDEV_DEV(netdev, &intf->dev);

        /* device needs access to shared ressources */
        chan->shared_res = shared_res;

        /* init work to reset channel (bus-off) */
        INIT_WORK(&chan->restart_work.work,
                systec_work_chan_restart);
        chan->restart_work.chan = chan;

        /* create mac address out of serial number, device number, channel number */
        for (i = 0; i < 4; i++) {
                netdev->dev_addr[i] = shared_res->serial_no[3 - i];
        }
        netdev->dev_addr[4] = shared_res->device_no;
        netdev->dev_addr[5] = chan_no;
        netdev->addr_len = 6;

        ret_stat = register_candev(netdev);
        if (ret_stat) {
                dev_err(netdev->dev.parent,
                        "couldn't register CAN device for channel %d: %d\n", chan_no, ret_stat);
                free_candev(netdev);
                return(ret_stat);
        }

        dev_info(&intf->dev, "registered device: %s (channel %d), %pM\n",
                netdev->name, chan->chan_no, netdev->dev_addr);

        return (0);
}


static int systec_can_main_probe(struct usb_interface *intf,
                            const struct usb_device_id *id)
{
        struct systec_can_shared *shared_res;
        struct usb_host_interface       *usb_host_intf;
        struct usb_endpoint_descriptor  *usb_endp_desc;
        int ret_stat = -ENOMEM;

        dev_dbg(&intf->dev, "systec_can_main_probe\n");

        if (id->idProduct != 0x1101 && id->idProduct != 0x1181) {
                /* boot device */
                return (systec_can_main_probe_boot(intf, id));
        }

        /* alloc ressource shared between both channels */
        shared_res = kzalloc(sizeof(struct systec_can_shared), GFP_KERNEL);
        if (!shared_res) {
                dev_err(&intf->dev, "couldn't alloc shared ressource\n");

                return (-ENOMEM);
        }

#if SYSTEC_DEBUG_USB_DISCONNECT
       dev_dbg(&intf->dev, "  shared_res: %p\n", shared_res);
#endif

        mutex_init(&shared_res->lock_shared);
        mutex_init(&shared_res->cmd_pending);

        shared_res->udev = interface_to_usbdev(intf);

        usb_host_intf = &intf->altsetting[0];
        if (intf->num_altsetting < 1 || usb_host_intf->desc.bNumEndpoints < 5) {
                dev_err(&intf->dev, "error in usb-endpoints\n");
                kfree(shared_res);
                return (-ENODEV);
        }

/*
        dev_dbg(&intf->dev, "  num_altsetting: %d\n", intf->num_altsetting);
        dev_dbg(&intf->dev, "  bNumEndpoints: %d\n", usb_host_intf->desc.bNumEndpoints);
*/

        /* get endpoints for fast access */
        usb_endp_desc = &usb_host_intf->endpoint[SYSTEC_EP_DATA_OUT].desc;
        if ((usb_endp_desc->bEndpointAddress & USB_ENDPOINT_DIR_MASK) == 0
            && (usb_endp_desc->bmAttributes  & USB_ENDPOINT_XFER_BULK) != 0) {
                shared_res->endpoint_addresses[SYSTEC_EP_DATA_OUT] = usb_endp_desc->bEndpointAddress;
        }
        else {
                dev_err(&intf->dev, "missing data-out endpoint\n");
                kfree(shared_res);
                return (-ENODEV);
        }

        usb_endp_desc = &usb_host_intf->endpoint[SYSTEC_EP_DATA_IN].desc;
        if ((usb_endp_desc->bEndpointAddress & USB_ENDPOINT_DIR_MASK) != 0
            && (usb_endp_desc->bmAttributes  & USB_ENDPOINT_XFER_BULK) != 0) {
                shared_res->endpoint_addresses[SYSTEC_EP_DATA_IN] = usb_endp_desc->bEndpointAddress;
        }
        else {
                dev_err(&intf->dev, "missing data-in endpoint\n");
                kfree(shared_res);
                return (-ENODEV);
        }


        usb_endp_desc = &usb_host_intf->endpoint[SYSTEC_EP_MSG_OUT].desc;
        if ((usb_endp_desc->bEndpointAddress & USB_ENDPOINT_DIR_MASK) == 0
            && (usb_endp_desc->bmAttributes  & USB_ENDPOINT_XFER_BULK) != 0) {
                shared_res->endpoint_addresses[SYSTEC_EP_MSG_OUT] = usb_endp_desc->bEndpointAddress;
        }
        else {
                dev_err(&intf->dev, "missing message-out endpoint\n");
                kfree(shared_res);
                return (-ENODEV);
        }

        usb_endp_desc = &usb_host_intf->endpoint[SYSTEC_EP_MSG_IN].desc;
        if ((usb_endp_desc->bEndpointAddress & USB_ENDPOINT_DIR_MASK) != 0
            && (usb_endp_desc->bmAttributes  & USB_ENDPOINT_XFER_BULK) != 0) {
                shared_res->endpoint_addresses[SYSTEC_EP_MSG_IN] = usb_endp_desc->bEndpointAddress;
        }
        else {
                dev_err(&intf->dev, "missing message-in endpoint\n");
                kfree(shared_res);
                return (-ENODEV);
        }

        usb_endp_desc = &usb_host_intf->endpoint[SYSTEC_EP_STAT_IN].desc;
        if ((usb_endp_desc->bEndpointAddress & USB_ENDPOINT_DIR_MASK) != 0
            && (usb_endp_desc->bmAttributes  & USB_ENDPOINT_XFER_BULK) != 0) {
                shared_res->endpoint_addresses[SYSTEC_EP_STAT_IN] = usb_endp_desc->bEndpointAddress;
        }
        else {
                dev_err(&intf->dev, "missing status endpoint\n");
                kfree(shared_res);
                return (-ENODEV);
        }

/*
        for (i = 0; i < 5; i++)
        {
                dev_dbg(&intf->dev, "    endpoint %d: %d\n", i, shared_res->endpoint_addresses[i]);
        }
*/

        /* init shared ressources */
        init_usb_anchor(&shared_res->rx_submitted);
        shared_res->intr_urb = NULL;

        shared_res->intr_in_buffer = kzalloc(INTR_IN_BUFFER_SIZE, GFP_KERNEL);
        if (!shared_res->intr_in_buffer) {
                dev_err(&intf->dev, "Couldn't alloc Intr buffer\n");
                kfree(shared_res);
                return (ret_stat);
        }

        shared_res->tx_cmd_buffer = kzalloc(sizeof(struct systec_cmd_msg), GFP_KERNEL);
        if (!shared_res->tx_cmd_buffer) {
                dev_err(&intf->dev, "Couldn't alloc Tx cmd buffer\n");
                kfree(shared_res->intr_in_buffer);
                kfree(shared_res);
                return (ret_stat);
        }

        shared_res->rx_cmd_buffer = kzalloc(sizeof(struct systec_cmd_msg), GFP_KERNEL);
        if (!shared_res->rx_cmd_buffer) {
                dev_err(&intf->dev, "Couldn't alloc Rx cmd buffer\n");
                kfree(shared_res->tx_cmd_buffer);
                kfree(shared_res->intr_in_buffer);
                kfree(shared_res);
                return (ret_stat);
        }

        systec_get_serial_no(shared_res);

        /* alloc channel 0 */
        ret_stat = systec_can_alloc_channel(intf, shared_res, 0);
        if (ret_stat != 0) {

                kfree(shared_res->rx_cmd_buffer);
                kfree(shared_res->tx_cmd_buffer);
                kfree(shared_res->intr_in_buffer);
                kfree(shared_res);
                return (ret_stat);
        }

        if (systec_dual_chan_device(shared_res)) {

                dev_dbg(&intf->dev, "    dual channel device found\n");

                /* alloc channel 1 */
                ret_stat = systec_can_alloc_channel(intf, shared_res, 1);
                if (ret_stat != 0) {

                        systec_can_free_channel(intf, shared_res, 0);
                        kfree(shared_res->rx_cmd_buffer);
                        kfree(shared_res->tx_cmd_buffer);
                        kfree(shared_res->intr_in_buffer);
                        kfree(shared_res);
                        return (ret_stat);
                }
        }

        /* attach shared ressources to USB interface */
        usb_set_intfdata(intf, shared_res);

        return 0;
}

static void systec_can_main_disconnect(struct usb_interface *intf)
{
        struct systec_can_shared *shared_res;
        int ret_stat;
#if SYSTEC_DEBUG_USB_DISCONNECT
        dev_dbg(&intf->dev, "systec_can_main_disconnect\n");
#endif

        shared_res = usb_get_intfdata(intf);
        if (!shared_res) {
#if SYSTEC_DEBUG_USB_DISCONNECT
                dev_warn(&intf->dev, "disconnect during boot\n");
#endif
                /* shared_res == NULL indicates a disconnect during boot */
                return;
        }

#if SYSTEC_DEBUG_USB_DISCONNECT
        dev_dbg(&intf->dev, "  shared_res: %p\n", shared_res);
#endif
        usb_set_intfdata(intf, NULL);

        if (shared_res) {

                if (shared_res->intr_urb_running) {
#if SYSTEC_DEBUG_USB_DISCONNECT
                        dev_dbg(&intf->dev, "  usb_unlink_urb (intr_urb)\n");
#endif
                        ret_stat = usb_unlink_urb(shared_res->intr_urb);
#if SYSTEC_DEBUG_USB_DISCONNECT
                        dev_dbg(&intf->dev, "    ret: %d\n", ret_stat);
#endif
                }


                if (shared_res->rx_urb_running) {
#if SYSTEC_DEBUG_USB_DISCONNECT
                        dev_dbg(&intf->dev, "  usb_kill_anchored_urbs (rx_submitted)\n");
#endif
                        usb_kill_anchored_urbs(&shared_res->rx_submitted);
                }

                systec_can_free_channel(intf, shared_res, 0);
                systec_can_free_channel(intf, shared_res, 1);

#if SYSTEC_DEBUG_USB_DISCONNECT
                dev_dbg(&intf->dev, "  usb_free_urb (intr_urb)\n");
#endif
                usb_free_urb(shared_res->intr_urb);

#if SYSTEC_DEBUG_USB_DISCONNECT
                dev_dbg(&intf->dev, "  kfree (intr_in_buffer)\n");
#endif
                kfree(shared_res->intr_in_buffer);

#if SYSTEC_DEBUG_USB_DISCONNECT
                dev_dbg(&intf->dev, "  kfree (tx_cmd_buffer)\n");
#endif
                kfree(shared_res->tx_cmd_buffer);

#if SYSTEC_DEBUG_USB_DISCONNECT
                dev_dbg(&intf->dev, "  kfree (rx_cmd_buffer)\n");
#endif
                kfree(shared_res->rx_cmd_buffer);

#if SYSTEC_DEBUG_USB_DISCONNECT
                dev_dbg(&intf->dev, "  kfree (shared_res)\n");
#endif
                kfree(shared_res);

        }
}


static int __init systec_can_main_init(void)
{
        int err;

        pr_debug("systec_can driver loaded\n");


        if (!cmd_wq) {
                /* create the work queue to handle commands */
                cmd_wq = create_workqueue("systec_wq");
                if (!cmd_wq) {

                        //err("    error: could not create work queue\n");
                        pr_debug("    error: could not create work queue\n");
/*
todo: proper return value
*/
                        return(-1);
                }
        }

        /* register this driver with the USB subsystem */
        err = usb_register(&systec_can_driver);

        if (err) {
                destroy_workqueue(cmd_wq);

                //err("usb_register failed. Error number %d\n", err);
                pr_debug("usb_register failed. Error number %d\n", err);
                return err;
        }

        return 0;
}


static void __exit systec_can_main_exit(void)
{
        pr_debug("systec_can_main_exit\n");

        destroy_workqueue(cmd_wq);

        /* deregister this driver with the USB subsystem */
        usb_deregister(&systec_can_driver);
}

module_init(systec_can_main_init);
module_exit(systec_can_main_exit);

MODULE_AUTHOR("Heino Gutschmidt <heino.gutschmidt@managedhosting.de>, "
              "Daniel Krueger <daniel.krueger@systec-electronic.com>");
MODULE_DESCRIPTION(SYSTEC_MODULE_DESC);
MODULE_VERSION(SYSTEC_MODULE_VERSION);
MODULE_LICENSE("GPL v2");
MODULE_FIRMWARE(FIRMWARE_FILE(REQ_FW_MAJOR, REQ_FW_MINOR, REQ_FW_RELEASE_1103, 1103));
MODULE_FIRMWARE(FIRMWARE_FILE(REQ_FW_MAJOR, REQ_FW_MINOR, REQ_FW_RELEASE_1104, 1104));
MODULE_FIRMWARE(FIRMWARE_FILE(REQ_FW_MAJOR, REQ_FW_MINOR, REQ_FW_RELEASE_1105, 1105));
MODULE_FIRMWARE(FIRMWARE_FILE(REQ_FW_MAJOR, REQ_FW_MINOR, REQ_FW_RELEASE_1144, 1144));
MODULE_FIRMWARE(FIRMWARE_FILE(REQ_FW_MAJOR, REQ_FW_MINOR, REQ_FW_RELEASE_1145, 1145));

